document.getElementById('search-form').addEventListener('submit', async function (e) {
    e.preventDefault();
    const location = document.getElementById('location').value; // Location not used in this mock API
    const category = document.getElementById('category').value;
  
    const response = await fetch(`http://localhost:3000/resources?category=${category}`);
    const resources = await response.json();
  
    const resourcesList = document.getElementById('resources-list');
    resourcesList.innerHTML = resources.map(resource => 
      `<li>${resource.name} - ${resource.address}</li>`
    ).join('');
  });
  
