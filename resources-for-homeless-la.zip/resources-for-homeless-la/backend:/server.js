const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

const resources = [
  { id: 1, name: "Shelter A", address: "123 Main St", category: "shelters" },
  { id: 2, name: "Food Bank B", address: "456 Oak St", category: "food-aid" },
  { id: 3, name: "Clinic C", address: "789 Pine St", category: "medical-help" }
];

// Endpoint to get resources by category
app.get('/resources', (req, res) => {
  const category = req.query.category;
  const filteredResources = resources.filter(resource => resource.category === category);
  res.json(filteredResources);
});

// Start the server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
